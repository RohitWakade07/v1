Usage:
```
python analyze.py
```